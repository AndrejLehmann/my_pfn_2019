#!/usr/bin/env python3
# Lehmann.Music
# Bearbeitungszeit: 0.05h

print("hello world")
