#!/usr/bin/env python3
# Bearbeitungszeit: 0.1h

import sys

for name in sys.argv[1:]:
    print("hello", name)
