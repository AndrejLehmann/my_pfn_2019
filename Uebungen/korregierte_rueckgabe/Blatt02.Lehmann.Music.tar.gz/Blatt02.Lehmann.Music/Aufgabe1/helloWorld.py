#!/usr/bin/env python3
# Bearbeitungszeit: 0.1h

# Eure Namen angeben
# Punkte: 2/2
# Korrektur: LZ

import sys

for name in sys.argv[1:]:
    print("hello", name)
