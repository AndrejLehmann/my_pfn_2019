# Lehmann.Music
# Bearbeitungszeit: 0.2h

# Punkte: 1/1
# Korrektur: LZ

alias rm="rm -i"
alias cp="cp -i"
alias mv="mv -i"
