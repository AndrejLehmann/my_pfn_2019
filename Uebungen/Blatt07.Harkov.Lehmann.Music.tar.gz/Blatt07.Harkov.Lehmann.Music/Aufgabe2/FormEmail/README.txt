Werte aus https://www.blutwert.net
