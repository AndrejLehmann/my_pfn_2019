# Lehmann.Music
# Bearbeitungszeit: 0.2h

alias rm="rm -i"
alias cp="cp -i"
alias mv="mv -i"
